import { Component, ReactNode, useCallback, useEffect, useRef, useState } from 'react';
import { Canvas } from '@react-three/fiber';
import { AdaptiveDpr } from '@react-three/drei';
import Scene from './Scene';
import { H, Hud, S, act, reset } from './engine';
import { setSound, sfx, unlock } from './audio';
import { AdSlot } from './ads';

type Phase = 'menu' | 'play' | 'pause' | 'over';
const ls = {
  get: (k: string) => { try { return localStorage.getItem(k); } catch { return null; } },
  set: (k: string, v: string) => { try { localStorage.setItem(k, v); } catch { /* ignore */ } },
};
const webglOk = () => {
  try {
    const c = document.createElement('canvas');
    return !!(c.getContext('webgl2') || c.getContext('webgl'));
  } catch { return false; }
};
const EMPTY: Hud = { score: 0, coins: 0, dist: 0, shield: 0, magnet: 0 };

class Boundary extends Component<{ children: ReactNode; fallback: ReactNode }, { err: boolean }> {
  state = { err: false };
  static getDerivedStateFromError() { return { err: true }; }
  render() { return this.state.err ? this.props.fallback : this.props.children; }
}

const Fail = () => (
  <div className="overlay"><div className="panel">
    <h1>WebGL unavailable</h1>
    <p>Your browser or device could not start 3D graphics. Enable hardware acceleration, update your browser, or try Chrome, Firefox or Safari.</p>
  </div></div>
);

function hintFor(d: number): string {
  if (d < 70) return 'Swipe left or right to change lanes';
  if (d < 140) return 'Swipe up to jump over low blocks and ramps';
  if (d < 210) return 'Swipe down to slide under red beams';
  if (d < 280) return 'Grab blue shields and red magnets!';
  return '';
}

export default function App() {
  const [phase, setPhase] = useState<Phase>('menu');
  const [hud, setHud] = useState<Hud>(EMPTY);
  const [best, setBest] = useState(() => Number(ls.get('chaos3d_best') || 0));
  const [sound, setSoundState] = useState(() => ls.get('chaos3d_sound') !== '0');
  const [reduced, setReduced] = useState(() => {
    const v = ls.get('chaos3d_reduced');
    return v === null ? (navigator.hardwareConcurrency || 8) <= 4 : v === '1';
  });
  const [ready, setReady] = useState(false);
  const [flash, setFlash] = useState(0);
  const [seen, setSeen] = useState(() => ls.get('chaos3d_seen') === '1');
  const [result, setResult] = useState({ score: 0, coins: 0, isBest: false });
  const [gl] = useState(webglOk);
  const phaseRef = useRef<Phase>('menu');
  const bestRef = useRef(best);
  const touch = useRef<{ x: number; y: number } | null>(null);
  phaseRef.current = phase;
  bestRef.current = best;
  S.reduced = reduced;

  const go = (p: Phase) => { phaseRef.current = p; setPhase(p); };

  const start = useCallback(() => {
    unlock(); reset(); setHud(EMPTY); S.running = true; go('play');
  }, []);
  const pause = useCallback(() => {
    if (phaseRef.current === 'play') { S.running = false; go('pause'); }
  }, []);
  const resume = useCallback(() => {
    unlock(); S.running = true; go('play');
  }, []);
  const menu = useCallback(() => { reset(); S.running = false; setHud(EMPTY); go('menu'); }, []);

  useEffect(() => {
    H.coin = () => sfx.coin();
    H.jump = () => sfx.jump();
    H.power = () => sfx.power();
    H.shield = () => { sfx.shield(); setFlash((f) => f + 1); };
    H.hud = setHud;
    H.hit = () => {
      S.running = false; sfx.hit(); setFlash((f) => f + 1);
      window.setTimeout(() => {
        const score = Math.floor(S.dist) + S.coins * 10;
        const isBest = score > bestRef.current;
        if (isBest) { setBest(score); ls.set('chaos3d_best', String(score)); }
        ls.set('chaos3d_seen', '1'); setSeen(true);
        setResult({ score, coins: S.coins, isBest });
        go('over');
      }, 750);
    };
  }, []);

  useEffect(() => { setSound(sound); ls.set('chaos3d_sound', sound ? '1' : '0'); }, [sound]);
  useEffect(() => { ls.set('chaos3d_reduced', reduced ? '1' : '0'); }, [reduced]);

  useEffect(() => {
    const keys: Record<string, () => void> = {
      ArrowLeft: () => act('left'), KeyA: () => act('left'),
      ArrowRight: () => act('right'), KeyD: () => act('right'),
      ArrowUp: () => act('jump'), KeyW: () => act('jump'), Space: () => act('jump'),
      ArrowDown: () => act('slide'), KeyS: () => act('slide'),
    };
    const down = (e: KeyboardEvent) => {
      const p = phaseRef.current;
      if (e.code === 'KeyP' || e.code === 'Escape') {
        e.preventDefault();
        if (p === 'play') pause(); else if (p === 'pause') resume();
        return;
      }
      if (e.code === 'Enter' && (p === 'menu' || p === 'over')) { start(); return; }
      if (p === 'play' && keys[e.code]) { e.preventDefault(); keys[e.code](); }
    };
    const vis = () => { if (document.hidden) pause(); };
    window.addEventListener('keydown', down);
    document.addEventListener('visibilitychange', vis);
    return () => { window.removeEventListener('keydown', down); document.removeEventListener('visibilitychange', vis); };
  }, [pause, resume, start]);

  const onDown = (e: React.PointerEvent) => { if (phaseRef.current === 'play') touch.current = { x: e.clientX, y: e.clientY }; };
  const onUp = (e: React.PointerEvent) => {
    const t = touch.current; touch.current = null;
    if (!t || phaseRef.current !== 'play') return;
    const dx = e.clientX - t.x, dy = e.clientY - t.y;
    if (Math.max(Math.abs(dx), Math.abs(dy)) < 28) return;
    if (Math.abs(dx) > Math.abs(dy)) act(dx > 0 ? 'right' : 'left');
    else act(dy < 0 ? 'jump' : 'slide');
  };
  const btn = (a: 'left' | 'right' | 'jump' | 'slide') => ({
    onPointerDown: (e: React.PointerEvent) => { e.preventDefault(); e.stopPropagation(); act(a); },
  });

  const hint = !seen && phase === 'play' ? hintFor(hud.dist) : '';

  return (
    <div className="stage" onPointerDown={onDown} onPointerUp={onUp} onPointerCancel={() => { touch.current = null; }}>
      {gl ? (
        <Boundary fallback={<Fail />}>
          <Canvas
            key={reduced ? 'low' : 'high'}
            shadows={!reduced}
            dpr={reduced ? 1 : [1, 1.75]}
            gl={{ antialias: !reduced, powerPreference: 'high-performance' }}
            camera={{ fov: 60, position: [0, 4.3, 7.5], near: 0.1, far: 140 }}
            onCreated={() => setReady(true)}
          >
            <AdaptiveDpr pixelated />
            <Scene />
          </Canvas>
        </Boundary>
      ) : <Fail />}

      {gl && !ready && <div className="overlay loading"><div className="spinner" />Loading CHAOS RUN 3D…</div>}
      {flash > 0 && <div key={flash} className="flash" />}

      {phase !== 'menu' && (
        <div className="hud">
          <div className="hud-left">
            <div className="score">{hud.score}</div>
            <div key={hud.coins} className="coins">● {hud.coins}</div>
          </div>
          <div className="hud-mid">
            {hud.shield > 0 && <span className="pw shield">Shield {Math.ceil(hud.shield)}s</span>}
            {hud.magnet > 0 && <span className="pw magnet">Magnet {Math.ceil(hud.magnet)}s</span>}
          </div>
          <button className="icon" aria-label="Pause" onPointerDown={(e) => e.stopPropagation()} onClick={pause}>❚❚</button>
        </div>
      )}
      {hint && <div className="hint">{hint}</div>}

      {phase === 'play' && (
        <div className="pad">
          <div><button className="pad-btn" aria-label="Move left" {...btn('left')}>◀</button><button className="pad-btn" aria-label="Move right" {...btn('right')}>▶</button></div>
          <div><button className="pad-btn" aria-label="Slide" {...btn('slide')}>▼</button><button className="pad-btn big" aria-label="Jump" {...btn('jump')}>▲</button></div>
        </div>
      )}

      {phase === 'menu' && gl && (
        <div className="overlay">
          <div className="panel">
            <h1 className="title">CHAOS<br />RUN 3D</h1>
            <p className="best">Best score {best}</p>
            <button className="cta" onClick={start}>Play</button>
            <ul className="how">
              <li><b>Swipe / arrows / WASD</b> change lanes, jump, slide</li>
              <li><b>Orange blocks</b> jump over &nbsp; <b>Red beams</b> slide under</li>
              <li><b>Blue ramps</b> launch you &nbsp; <b>Pink walls</b> dodge</li>
              <li><b>Shield</b> absorbs one hit &nbsp; <b>Magnet</b> pulls coins</li>
              <li><b>P / Esc</b> pauses</li>
            </ul>
            <div className="row">
              <button className="chip" onClick={() => setSoundState(!sound)}>Sound: {sound ? 'On' : 'Off'}</button>
              <button className="chip" onClick={() => setReduced(!reduced)}>Reduced effects: {reduced ? 'On' : 'Off'}</button>
            </div>
            <AdSlot placement="menu" />
          </div>
        </div>
      )}

      {phase === 'pause' && (
        <div className="overlay"><div className="panel">
          <h2>Paused</h2>
          <button className="cta" onClick={resume}>Resume</button>
          <div className="row">
            <button className="chip" onClick={() => setSoundState(!sound)}>Sound: {sound ? 'On' : 'Off'}</button>
            <button className="chip" onClick={start}>Restart</button>
            <button className="chip" onClick={menu}>Menu</button>
          </div>
        </div></div>
      )}

      {phase === 'over' && (
        <div className="overlay"><div className="panel">
          <h2>Game over</h2>
          {result.isBest && <p className="newbest">New best score!</p>}
          <p className="big">{result.score}</p>
          <p>Coins collected: {result.coins} &nbsp;|&nbsp; Best: {best}</p>
          <button className="cta" onClick={start}>Run again</button>
          <div className="row"><button className="chip" onClick={menu}>Menu</button></div>
          <AdSlot placement="gameover" />
        </div></div>
      )}
    </div>
  );
}
