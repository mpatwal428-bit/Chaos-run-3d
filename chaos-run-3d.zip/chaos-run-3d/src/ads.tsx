import { useEffect, useRef } from 'react';

/**
 * OPTIONAL AD INTEGRATION POINT - DISABLED BY DEFAULT.
 * No ad code or publisher IDs are included. Ads only ever render on the menu and
 * game-over screens (never during play), and only when enabled AND consent is granted.
 * See README.md "Monetization" before enabling.
 */
export type AdPlacement = 'menu' | 'gameover';

export interface AdConfig {
  enabled: boolean;
  requireConsent: boolean;
  placements: AdPlacement[];
  /** Mount your approved ad provider's tag into `el`. Return a cleanup function if needed. */
  mount?: (el: HTMLElement) => void | (() => void);
}

export const adConfig: AdConfig = {
  enabled: false,
  requireConsent: true,
  placements: ['menu', 'gameover'],
};

/** Replace with your Consent Management Platform check (required in EEA/UK/etc.). */
export function hasConsent(): boolean { return false; }

export function AdSlot({ placement }: { placement: AdPlacement }) {
  const ref = useRef<HTMLDivElement>(null);
  const on = adConfig.enabled && adConfig.placements.includes(placement) && (!adConfig.requireConsent || hasConsent());
  useEffect(() => {
    if (!on || !ref.current || !adConfig.mount) return;
    const cleanup = adConfig.mount(ref.current);
    return typeof cleanup === 'function' ? cleanup : undefined;
  }, [on]);
  return on ? <div className="ad-slot" ref={ref} aria-label="Advertisement" /> : null;
}
