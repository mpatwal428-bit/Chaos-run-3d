export const LANE = 2.2;
export type Kind = 'block' | 'tall' | 'beam' | 'ramp' | 'coin' | 'shield' | 'magnet';
export const KINDS: Kind[] = ['block', 'tall', 'beam', 'ramp', 'coin', 'shield', 'magnet'];
export interface Ent { kind: Kind; x: number; y: number; z: number; on: boolean; done: boolean }
export interface Hud { score: number; coins: number; dist: number; shield: number; magnet: number }
export const MAXE = 60;

/** Event hooks assigned by the UI layer. */
export const H = {
  coin: () => {}, hit: () => {}, power: () => {}, jump: () => {}, shield: () => {},
  hud: (_h: Hud) => {},
};

export const S = {
  ents: Array.from({ length: MAXE }, (): Ent => ({ kind: 'coin', x: 0, y: 0.8, z: 0, on: false, done: false })),
  lane: 0, x: 0, y: 0, vy: 0, slide: 0, dist: 0, speed: 16, coins: 0,
  shield: 0, magnet: 0, inv: 0, shake: 0, hudT: 0, spawnZ: -45,
  running: false, alive: true, reduced: false,
};

export function reset() {
  S.ents.forEach((e) => { e.on = false; });
  Object.assign(S, { lane: 0, x: 0, y: 0, vy: 0, slide: 0, dist: 0, speed: 16, coins: 0, shield: 0, magnet: 0, inv: 0, shake: 0, hudT: 0, spawnZ: -45, alive: true });
}

function add(kind: Kind, lane: number, z: number, y = 0.8) {
  const e = S.ents.find((q) => !q.on);
  if (!e) return;
  e.on = true; e.done = false; e.kind = kind; e.x = lane * LANE; e.y = y; e.z = z;
}

/** Spawns one pattern at z; returns extra gap to leave afterwards. */
function spawn(z: number): number {
  const d = Math.min(1, S.dist / 1800);
  const r = Math.random();
  const l = Math.floor(Math.random() * 3) - 1;
  const other = () => ((l + 1 + 1 + Math.floor(Math.random() * 2)) % 3) - 1;
  if (r < 0.22) {
    for (let k = 0; k < 6; k++) add('coin', l, z - k * 1.8);
  } else if (r < 0.42) {
    add('block', l, z);
    for (let k = -1; k <= 1; k++) add('coin', l, z - k * 1.2, 2.0);
    if (Math.random() < d) add('block', other(), z);
  } else if (r < 0.56) {
    add('ramp', l, z);
    for (let k = 0; k < 5; k++) add('coin', l, z - 4 - k * 2, 2.2);
    return 14;
  } else if (r < 0.7) {
    add('beam', l, z);
    if (Math.random() < 0.4 + d * 0.4) add('beam', other(), z);
    for (let k = -1; k <= 2; k++) add('coin', l, z - k * 1.5);
  } else if (r < 0.86) {
    for (let i = -1; i <= 1; i++) if (i !== l) add('tall', i, z);
    for (let k = 0; k < 5; k++) add('coin', l, z - k * 1.8);
  } else {
    add(Math.random() < 0.5 ? 'shield' : 'magnet', l, z, 1.0);
    add('block', other(), z);
  }
  return 0;
}

export function act(a: 'left' | 'right' | 'jump' | 'slide') {
  if (!S.running || !S.alive) return;
  if (a === 'left') S.lane = Math.max(-1, S.lane - 1);
  else if (a === 'right') S.lane = Math.min(1, S.lane + 1);
  else if (a === 'jump') {
    if (S.y < 0.05) { S.vy = 10.5; S.slide = 0; H.jump(); }
  } else {
    S.slide = 0.7;
    if (S.y > 0.05) S.vy = -20;
  }
}

function crash(e: Ent) {
  if (S.inv > 0) return;
  if (S.shield > 0) {
    S.shield = 0; S.inv = 1; S.shake = 0.6; e.on = false; H.shield();
  } else {
    S.alive = false; S.shake = 1; H.hit();
  }
}

export function update(dt: number) {
  if (!S.running || !S.alive) return;
  const sp = (S.speed = Math.min(30, 16 + S.dist * 0.0075));
  const mv = sp * dt;
  S.dist += mv;
  S.x += (S.lane * LANE - S.x) * Math.min(1, dt * 14);
  S.vy -= 30 * dt;
  S.y += S.vy * dt;
  if (S.y <= 0) { S.y = 0; S.vy = 0; }
  S.slide = Math.max(0, S.slide - dt);
  S.shield = Math.max(0, S.shield - dt);
  S.magnet = Math.max(0, S.magnet - dt);
  S.inv = Math.max(0, S.inv - dt);
  S.shake = Math.max(0, S.shake - dt * 2);

  S.spawnZ += mv;
  while (S.spawnZ > -110) {
    const extra = spawn(S.spawnZ);
    S.spawnZ -= 18 - Math.min(1, S.dist / 1800) * 4 + extra;
  }

  const top = S.y + (S.slide > 0 && S.y < 0.2 ? 0.8 : 1.7);
  for (const e of S.ents) {
    if (!e.on) continue;
    e.z += mv;
    if (e.z > 6) { e.on = false; continue; }
    if (e.kind === 'coin' && S.magnet > 0 && e.z > -16 && e.z < 3) {
      const k = Math.min(1, dt * 8);
      e.x += (S.x - e.x) * k; e.y += (S.y + 0.8 - e.y) * k; e.z += mv * 0.35;
    }
    if (e.done) continue;
    const dx = Math.abs(e.x - S.x);
    const az = Math.abs(e.z);
    switch (e.kind) {
      case 'coin':
        if (az < 0.9 && dx < 1.1 && Math.abs(e.y - (S.y + 0.8)) < 1.3) { e.on = false; S.coins++; H.coin(); }
        break;
      case 'shield':
      case 'magnet':
        if (az < 1 && dx < 1.2) {
          e.on = false;
          if (e.kind === 'shield') S.shield = 8; else S.magnet = 8;
          H.power();
        }
        break;
      case 'block':
        if (az < 0.8 && dx < 0.95 && S.y < 0.8) crash(e);
        break;
      case 'tall':
        if (az < 0.8 && dx < 0.95) crash(e);
        break;
      case 'beam':
        if (az < 0.6 && dx < 0.95 && top > 1.15 && S.y < 2.0) crash(e);
        break;
      case 'ramp':
        if (az < 1.2 && dx < 1 && S.y < 0.6) { S.vy = 13; e.done = true; H.jump(); }
        break;
    }
  }

  S.hudT += dt;
  if (S.hudT > 0.1) {
    S.hudT = 0;
    H.hud({ score: Math.floor(S.dist) + S.coins * 10, coins: S.coins, dist: S.dist, shield: S.shield, magnet: S.magnet });
  }
}
