import { useMemo, useRef } from 'react';
import { useFrame } from '@react-three/fiber';
import * as THREE from 'three';
import { KINDS, MAXE, S, update } from './engine';

const box = new THREE.BoxGeometry(1, 1, 1);
const cyl = new THREE.CylinderGeometry(0.4, 0.4, 0.12, 14);
const sph = new THREE.SphereGeometry(0.5, 16, 12);
const cone = new THREE.ConeGeometry(1, 1, 7);
const tor = new THREE.TorusGeometry(0.4, 0.14, 8, 16);
const mat = (color: string, emissive = '#000000', ei = 0) =>
  new THREE.MeshStandardMaterial({ color, emissive, emissiveIntensity: ei, roughness: 0.6 });
const M = {
  road1: mat('#3a3f78'), road2: mat('#454b8c'), line: mat('#9aa4ff', '#9aa4ff', 0.4),
  rail: mat('#ff5d73', '#ff5d73', 0.35), orange: mat('#ff9f1c'), magenta: mat('#e63da8'),
  stripe: mat('#fff3b0', '#fff3b0', 0.3), gold: mat('#ffd23f', '#ffb700', 0.6),
  blue: mat('#4cc9f0', '#4cc9f0', 0.7), red: mat('#ff3b5c', '#ff3b5c', 0.6),
  skin: mat('#ffd9b3'), shirt: mat('#3ddc97'), pants: mat('#2b2d6e'), hair: mat('#ff5d73'),
  leaf: mat('#2fbf71'), trunk: mat('#7a4b2a'), pylon: mat('#6a4dff', '#6a4dff', 0.5),
  sun: new THREE.MeshBasicMaterial({ color: '#fff1a8', fog: false }),
  bubble: new THREE.MeshStandardMaterial({ color: '#4cc9f0', transparent: true, opacity: 0.3, emissive: '#4cc9f0', emissiveIntensity: 0.5 }),
};

type MP = { g: THREE.BufferGeometry; m: THREE.Material; p?: [number, number, number]; s?: [number, number, number]; r?: [number, number, number]; cast?: boolean };
function P({ g, m, p, s, r, cast }: MP) {
  return <mesh geometry={g} material={m} position={p} scale={s} rotation={r} castShadow={cast} />;
}

function Slot({ cast }: { cast: boolean }) {
  return (
    <group>
      <group>{/* block */}
        <P g={box} m={M.orange} p={[0, 0.45, 0]} s={[1.8, 0.9, 0.9]} cast={cast} />
        <P g={box} m={M.stripe} p={[0, 0.6, 0.46]} s={[1.8, 0.18, 0.02]} />
      </group>
      <group>{/* tall */}
        <P g={box} m={M.magenta} p={[0, 1.3, 0]} s={[1.8, 2.6, 1]} cast={cast} />
        <P g={box} m={M.stripe} p={[0, 2.0, 0.51]} s={[1.8, 0.2, 0.02]} />
      </group>
      <group>{/* beam */}
        <P g={box} m={M.red} p={[0, 1.6, 0]} s={[2, 0.8, 0.5]} cast={cast} />
        <P g={box} m={M.stripe} p={[0, 1.6, 0.26]} s={[2, 0.12, 0.02]} />
        <P g={box} m={M.pants} p={[-0.95, 0.9, 0]} s={[0.2, 1.8, 0.2]} />
        <P g={box} m={M.pants} p={[0.95, 0.9, 0]} s={[0.2, 1.8, 0.2]} />
      </group>
      <group>{/* ramp */}
        <P g={box} m={M.blue} p={[0, 0.55, 0]} s={[1.8, 0.2, 4.2]} r={[0.3, 0, 0]} cast={cast} />
      </group>
      <group><P g={cyl} m={M.gold} r={[Math.PI / 2, 0, 0]} /></group>
      <group>
        <P g={sph} m={M.bubble} s={[0.9, 0.9, 0.9]} />
        <P g={box} m={M.blue} s={[0.35, 0.45, 0.1]} />
      </group>
      <group><P g={tor} m={M.red} r={[0, 0, 0]} /><P g={box} m={M.stripe} p={[0, -0.4, 0]} s={[0.9, 0.15, 0.15]} /></group>
    </group>
  );
}

const TILES = 12;

export default function Scene() {
  const slots = useRef<THREE.Group[]>([]);
  const tiles = useRef<THREE.Group[]>([]);
  const deco = useRef<THREE.Group[]>([]);
  const player = useRef<THREE.Group>(null);
  const body = useRef<THREE.Group>(null);
  const legL = useRef<THREE.Mesh>(null);
  const legR = useRef<THREE.Mesh>(null);
  const armL = useRef<THREE.Mesh>(null);
  const armR = useRef<THREE.Mesh>(null);
  const bubble = useRef<THREE.Mesh>(null);
  const run = useRef(0);
  const cast = !S.reduced;
  const decoCount = S.reduced ? 6 : TILES;
  const rnd = useMemo(() => Array.from({ length: TILES * 2 }, () => ({ o: Math.random() * 4, h: 0.8 + Math.random() * 1.2 })), []);

  useFrame((state, delta) => {
    const dt = Math.min(delta, 0.05);
    const t = state.clock.elapsedTime;
    update(dt);

    // scrolling track + scenery
    const off = S.dist % 24;
    for (let i = 0; i < TILES; i++) {
      const z = off - i * 12 + 6;
      const tg = tiles.current[i];
      if (tg) tg.position.z = z;
      for (let side = 0; side < 2; side++) {
        const dg = deco.current[i * 2 + side];
        if (dg) dg.position.z = z + rnd[i * 2 + side].o - 2;
      }
    }

    // entities
    for (let i = 0; i < MAXE; i++) {
      const g = slots.current[i];
      if (!g) continue;
      const e = S.ents[i];
      if (!e.on) { g.visible = false; continue; }
      g.visible = true;
      g.position.set(e.x, 0, e.z);
      if (g.userData.k !== e.kind) {
        g.userData.k = e.kind;
        g.children.forEach((c, k) => { c.visible = KINDS[k] === e.kind; });
      }
      if (e.kind === 'coin' || e.kind === 'shield' || e.kind === 'magnet') {
        const c = g.children[KINDS.indexOf(e.kind)];
        c.position.y = e.y + Math.sin(t * 4 + i) * 0.08;
        c.rotation.y = t * 3;
      }
    }

    // player
    const p = player.current;
    if (p && body.current) {
      p.position.set(S.x, S.y, 0);
      const sliding = S.slide > 0 && S.y < 0.2;
      body.current.scale.y += ((sliding ? 0.55 : 1) - body.current.scale.y) * Math.min(1, dt * 18);
      body.current.rotation.x = sliding ? -0.5 : 0;
      p.rotation.z += ((S.x - S.lane * 2.2) * 0.1 - p.rotation.z) * Math.min(1, dt * 10);
      if (S.running && S.alive) run.current += dt * S.speed * 0.7;
      const a = Math.sin(run.current) * (S.y > 0.05 ? 0.3 : 0.9);
      if (legL.current && legR.current && armL.current && armR.current) {
        legL.current.rotation.x = a; legR.current.rotation.x = -a;
        armL.current.rotation.x = -a; armR.current.rotation.x = a;
      }
      p.visible = !(S.inv > 0 && Math.floor(t * 14) % 2 === 0);
      if (!S.alive) p.rotation.x = -0.4;
      else p.rotation.x = 0;
    }
    if (bubble.current) {
      bubble.current.visible = S.shield > 0;
      bubble.current.scale.setScalar(1.7 + Math.sin(t * 6) * 0.05);
    }

    // camera
    const cam = state.camera as THREE.PerspectiveCamera;
    const sh = S.shake * 0.3;
    cam.position.x += (S.x * 0.6 - cam.position.x) * Math.min(1, dt * 6);
    cam.position.y = 4.3 + (Math.random() - 0.5) * sh;
    cam.position.z = 7.5;
    cam.fov += ((60 + (S.speed - 16) * 0.35) - cam.fov) * Math.min(1, dt * 3);
    cam.updateProjectionMatrix();
    cam.lookAt(S.x * 0.4, 1.3, -8);
  });

  return (
    <>
      <color attach="background" args={['#8fd3ff']} />
      <fog attach="fog" args={['#8fd3ff', 30, 100]} />
      <hemisphereLight args={['#ffffff', '#6a4dff', 0.9]} />
      <directionalLight
        position={[6, 12, 6]} intensity={1.4} castShadow={cast}
        shadow-mapSize={[1024, 1024]} shadow-camera-left={-8} shadow-camera-right={8}
        shadow-camera-top={10} shadow-camera-bottom={-12} shadow-camera-near={1} shadow-camera-far={40}
      />
      <mesh geometry={sph} material={M.sun} position={[0, 20, -100]} scale={[16, 16, 16]} />

      {Array.from({ length: TILES }, (_, i) => (
        <group key={i} ref={(g) => { if (g) tiles.current[i] = g; }}>
          <P g={box} m={i % 2 ? M.road1 : M.road2} p={[0, -0.1, 0]} s={[7.2, 0.2, 12]} />
          <P g={box} m={M.line} p={[-1.1, 0.005, 0]} s={[0.08, 0.02, 9]} />
          <P g={box} m={M.line} p={[1.1, 0.005, 0]} s={[0.08, 0.02, 9]} />
          <P g={box} m={M.rail} p={[-3.8, 0.25, 0]} s={[0.4, 0.5, 12]} />
          <P g={box} m={M.rail} p={[3.8, 0.25, 0]} s={[0.4, 0.5, 12]} />
          <P g={box} m={M.leaf} p={[-12, -0.3, 0]} s={[14, 0.2, 12]} />
          <P g={box} m={M.leaf} p={[12, -0.3, 0]} s={[14, 0.2, 12]} />
        </group>
      ))}

      {Array.from({ length: TILES * 2 }, (_, k) => {
        if (k >> 1 >= decoCount) return null;
        const side = k % 2 ? 1 : -1;
        const tree = (k >> 1) % 3 !== 2;
        const h = rnd[k].h;
        return (
          <group key={k} ref={(g) => { if (g) deco.current[k] = g; }} position={[side * (6.5 + rnd[k].o * 1.5), 0, 0]}>
            {tree ? (
              <>
                <P g={box} m={M.trunk} p={[0, 0.6, 0]} s={[0.4, 1.2, 0.4]} />
                <P g={cone} m={M.leaf} p={[0, 2.2 * h, 0]} s={[1.6 * h, 3 * h, 1.6 * h]} cast={cast} />
              </>
            ) : (
              <P g={box} m={M.pylon} p={[0, 2.5 * h, 0]} s={[0.8, 5 * h, 0.8]} />
            )}
          </group>
        );
      })}

      {Array.from({ length: MAXE }, (_, i) => (
        <group key={i} visible={false} ref={(g) => { if (g) slots.current[i] = g; }}>
          <Slot cast={cast} />
        </group>
      ))}

      <group ref={player}>
        <group ref={body}>
          <P g={box} m={M.shirt} p={[0, 1.05, 0]} s={[0.7, 0.8, 0.4]} cast={cast} />
          <P g={sph} m={M.skin} p={[0, 1.7, 0]} s={[0.55, 0.55, 0.55]} cast={cast} />
          <P g={box} m={M.hair} p={[0, 1.88, 0.02]} s={[0.5, 0.18, 0.5]} />
          <mesh ref={armL} geometry={box} material={M.skin} position={[-0.47, 1.1, 0]} scale={[0.18, 0.7, 0.18]} />
          <mesh ref={armR} geometry={box} material={M.skin} position={[0.47, 1.1, 0]} scale={[0.18, 0.7, 0.18]} />
          <mesh ref={legL} geometry={box} material={M.pants} position={[-0.17, 0.35, 0]} scale={[0.26, 0.7, 0.28]} castShadow={cast} />
          <mesh ref={legR} geometry={box} material={M.pants} position={[0.17, 0.35, 0]} scale={[0.26, 0.7, 0.28]} castShadow={cast} />
        </group>
        <mesh ref={bubble} geometry={sph} material={M.bubble} position={[0, 1, 0]} visible={false} />
      </group>
    </>
  );
}
