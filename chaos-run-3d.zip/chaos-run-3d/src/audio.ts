let ctx: AudioContext | null = null;
let enabled = true;

export function setSound(v: boolean) { enabled = v; }

export function unlock() {
  try {
    if (!ctx) {
      const AC = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      ctx = new AC();
    }
    if (ctx.state === 'suspended') void ctx.resume();
  } catch { /* audio unavailable */ }
}

function tone(f: number, d: number, type: OscillatorType, v: number, to?: number) {
  if (!enabled || !ctx) return;
  try {
    const t = ctx.currentTime;
    const o = ctx.createOscillator();
    const g = ctx.createGain();
    o.type = type;
    o.frequency.setValueAtTime(f, t);
    if (to) o.frequency.exponentialRampToValueAtTime(to, t + d);
    g.gain.setValueAtTime(v, t);
    g.gain.exponentialRampToValueAtTime(0.0001, t + d);
    o.connect(g);
    g.connect(ctx.destination);
    o.start(t);
    o.stop(t + d);
  } catch { /* ignore */ }
}

export const sfx = {
  coin: () => tone(880, 0.09, 'square', 0.04, 1320),
  jump: () => tone(300, 0.15, 'triangle', 0.07, 620),
  hit: () => tone(180, 0.5, 'sawtooth', 0.09, 40),
  power: () => { tone(520, 0.14, 'sine', 0.08, 1040); },
  shield: () => tone(260, 0.3, 'square', 0.07, 90),
};
